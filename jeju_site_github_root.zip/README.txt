GitHub Pages 업로드 구조

index.html
assets/
  jeju-hero-01.webp
  jeju-hero-02.webp
  jeju-hero-03.webp

위 구조 그대로 GitHub 저장소 루트에 올리면 됩니다.
HTML 안의 이미지 src는 ./assets/jeju-hero-01.webp 형식으로 폴더에서 불러오도록 수정되어 있습니다.
